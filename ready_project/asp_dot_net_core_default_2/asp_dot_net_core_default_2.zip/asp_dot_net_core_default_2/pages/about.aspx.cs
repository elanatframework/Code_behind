﻿using CodeBehind;

namespace CoreDefault2
{
    public partial class AboutModel : CodeBehindModel
    {
        public string Message { get; set; }
        public void CodeBehindConstructor(HttpContext context)
        {
            Message = "Your application description page.";
        }
    }
}