﻿using CodeBehind;

namespace CoreDefault2
{
    public partial class AcceptCookieController : CodeBehindController
    {
        public bool AcceptCookie { get; set; }

        public void PageLoad(HttpContext context)
        {
            AcceptCookie = context.Request.Cookies["AcceptCookie"] != null;
        }
    }
}