﻿using CodeBehind;

namespace CoreDefault2
{
    public partial class PrivacyModel : CodeBehindModel
    {
        public void CodeBehindConstructor(HttpContext context)
        {

        }
    }
}