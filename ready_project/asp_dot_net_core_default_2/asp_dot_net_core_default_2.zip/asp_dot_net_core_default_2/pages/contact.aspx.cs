﻿using CodeBehind;

namespace CoreDefault2
{
    public partial class ContactModel : CodeBehindModel
    {
        public string Message { get; set; }
        public void CodeBehindConstructor(HttpContext context)
        {
            Message = "Your contact page.";
        }
    }
}