﻿using CodeBehind;

namespace CoreDefault2
{
    public partial class DefaultModel : CodeBehindModel
    {
        public void CodeBehindConstructor(HttpContext context)
        {

        }
    }
}