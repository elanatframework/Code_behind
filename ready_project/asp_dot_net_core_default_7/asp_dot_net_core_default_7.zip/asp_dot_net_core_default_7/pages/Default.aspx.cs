﻿using CodeBehind;

namespace CoreDefault7
{
    public partial class DefaultModel : CodeBehindModel
    {
        public void CodeBehindConstructor(HttpContext context)
        {
           
        }
    }
}