using CodeBehind;
using System.Diagnostics;

namespace CoreDefault7
{
    public partial class ErrorModel : CodeBehindModel
    {
        public string? RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);

        public void CodeBehindConstructor(HttpContext context)
        {
            RequestId = Activity.Current?.Id ?? context.TraceIdentifier;
        }
    }
}