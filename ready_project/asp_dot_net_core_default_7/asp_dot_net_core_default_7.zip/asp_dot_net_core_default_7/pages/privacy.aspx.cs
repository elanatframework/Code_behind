﻿using CodeBehind;

namespace CoreDefault7
{
    public partial class PrivacyModel : CodeBehindModel
    {
        public void CodeBehindConstructor(HttpContext context)
        {

        }
    }
}